package com.example.reviewsongservice.query;

public class FindReviewSongsQuery {
}
