package com.example.reviewpodcastservice.query;

public class FindReviewPodcastsQuery {
}
