package com.example.reviewmembershipservice.query;

public class FindReviewMembershipQuery {
}
