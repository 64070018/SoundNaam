package com.example.reviewmembershipservice.query;

import lombok.Data;

@Data
public class FindReviewEachMembershipQuery {
    private String postId;
}
