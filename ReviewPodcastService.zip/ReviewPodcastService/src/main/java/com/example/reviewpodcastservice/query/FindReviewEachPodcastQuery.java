package com.example.reviewpodcastservice.query;

import lombok.Data;

@Data
public class FindReviewEachPodcastQuery {
    private String podcastId;
}
