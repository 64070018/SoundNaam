package com.example.reviewsongservice.query;

import lombok.Data;

@Data
public class FindReviewEachSongQuery {
    private String songId;
}
