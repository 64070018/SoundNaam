export declare const popupStyles: import("lit").CSSResult;
