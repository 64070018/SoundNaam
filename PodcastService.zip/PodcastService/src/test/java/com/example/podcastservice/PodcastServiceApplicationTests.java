package com.example.podcastservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PodcastServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
