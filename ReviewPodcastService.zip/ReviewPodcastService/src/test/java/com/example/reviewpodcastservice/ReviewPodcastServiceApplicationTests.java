package com.example.reviewpodcastservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewPodcastServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
